Gestão de Tarefas

Sobre o trabalho:

O trabalho de faculdade consiste na criação de uma aplicação de lista de tarefas, com o objetivo de auxiliar os usuários na organização e gerenciamento de suas atividades diárias.


Membros:
@debora
@emily